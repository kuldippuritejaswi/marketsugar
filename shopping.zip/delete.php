<?php
$name = "[hi] helloz [hello] (hi) {jhihi}";
echo preg_replace('/[\[{\(].*[\]}\)]/U' , '', $name); 
?>