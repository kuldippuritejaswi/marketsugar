<?php
	if(isset($_POST['tbl'])){
		session_start();
		$table = $_SESSION['tbl_name'];
		
		mysql_connect('localhost','root','');
		mysql_select_db('shopping');
		
		$result = mysql_query("SELECT * FROM cart WHERE table_name = '$table' ORDER BY id DESC");
		//[id] => 1
    //[pro_id] => 119
    //[] => http://ecx.images-amazon.com/images/I/41o1svObnnL._SL160_.jpg
    //[status] => online
    //[sell_status] => 
    //[shop_id] => MIOIM_Womens_Summer_Casual_Short_Sleeve_Shirt_Tops_Blouse_Ladies_Lace_Casual_Top_Tank
    //[pro_title] => undefined
    //[price] => 598
    //[table_name] => ipaddr00001
    //[shop_name] => undefined
		$amount = 0;
		while($each_result = mysql_fetch_assoc($result)){
			$amount+=$each_result['price'];
			if($each_result['status'] == 'online'){
				$pro_id = $each_result['pro_id'];
				echo '<div style="width:100%;float:left;height:auto;border-bottom:1px solid green;padding-bottom:5px">
						<div style="padding:4px">
							<div style="width:100%;float:left;height:auto">
								<div style="width:100%;float:left">
									<div style="width:80px;float:left">
										<img src="'.$each_result['pro_image'].'" style="max-width:80px;max-height:80px" />
									</div>
									<div style="float:left;max-width:250px;padding:10px;padding-top:30px">
										'.substr(str_replace("_"," ",$each_result['shop_id']) ,0,40).'
									</div>
									<div style="width:70px;float:right;padding-top:25px;font-size:20px">
										<strong>&#8377;'.$each_result['price'].'</strong>
									</div>
								</div>
								<div style="width:100%;float:left">
									<div style="width:20%;float:left;color:red;font-size:12px;padding-top:5px;cursor:pointer" onClick=remove_cart('.$each_result['id'].')>
										Remove
									</div>
									<div style="width:20%;float:left;color:red;font-size:12px">
										<input type="text"  id="pro_quantity_'.$pro_id.'" style="width:40px;padding:4px" />
									</div>
									<div style="width:50%;float:left">
										';
										$link = mysql_fetch_assoc(mysql_query("SELECT prod_link FROM $table WHERE id= '$pro_id' LIMIT 1"));
										echo '<a style="text-decoration:none;coloe:green;color:green;font-size:18px" href="'.$link['prod_link'].'">Buy</a>';
										
									echo '</div>
								</div>
							</div>
						</div>
					  </div>';
			}else{
				echo '<div style="width:100%;float:left;height:auto;border-bottom:1px solid green;padding-bottom:5px">
						<div style="padding:4px">
							<div style="width:100%;float:left;height:auto">
								<div style="width:100%;float:left">
									<div style="width:80px;float:left">
										<img src="'.$each_result['pro_image'].'" style="max-width:80px;max-height:80px" />
									</div>
									<div style="float:left;max-width:250px;padding:10px;padding-top:30px">
										'.substr(str_replace("_"," ",$each_result['pro_title']) ,0,40).'
									</div>
									<div style="width:70px;float:right;padding-top:25px;font-size:20px">
										<strong>&#8377;'.$each_result['price'].'</strong>
									</div>
								</div>
								<div style="width:100%;float:left">
									<div style="width:20%;float:left;color:red;font-size:12px;padding-top:5px;cursor:pointer" onClick=remove_cart('.$each_result['id'].')>
										Remove
									</div>
									<div style="width:50%;float:left">
										';
								$link ="http://localhost/shopping/vendors/public_profile.php?id=".$each_result['shop_id'];
										echo '<a  style="text-decoration:none;coloe:green;color:green;font-size:18px" href="'.$link.'" target="_blank">Buy</a>';
										
									echo '</div>
								</div>
							</div>
						</div>
					  </div>';
			}
			
		}
		echo '<div style="width:100%;float:left;font-size:20px;"><strong>Total Amount<span style="margin-left:40px">&#8377;'.$amount.'</span></strong></div>';
	}
?>