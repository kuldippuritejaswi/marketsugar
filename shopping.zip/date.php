<?php
echo date("m.d.y");
?>