<?php
mysql_connect("localhost","root","");
mysql_select_db("vendors_shop");
		
session_start();
$id = $_SESSION['id'];

if($_POST['timeline'] == 'detail'){
	
	$fetching_detail = mysql_query("SELECT id,vendor_name,email,mobile,pin_code,city,country,registered_on,shop_desc FROM personal_detail WHERE id='$id'");
	$fetching_location = mysql_query("SELECT * FROM map_location WHERE vendor_id = '$id'");
	
	$fetch_detail = mysql_fetch_assoc($fetching_detail);
		$each_result_2[] = $fetch_detail;
	$fetch_loc = mysql_fetch_assoc($fetching_location);
		$each_result_2[] = $fetch_loc;
	echo json_encode($each_result_2);
}

elseif($_POST['timeline'] == 'feedback'){
	$fetch_feed_back = mysql_query("SELECT * FROM feed_back WHERE shop_id = '$id'");
	while($result = mysql_fetch_assoc($fetch_feed_back)){
		$feedback[] = $result;
	}
	echo json_encode($feedback);
}

elseif($_POST['timeline'] == 'product'){
	$product = mysql_query("SELECT * FROM product WHERE shop_id='$id'");
	while($each_product = mysql_fetch_assoc($product)){
		$productjson[] = $each_product;
	}
	echo json_encode($productjson);
}

elseif($_POST['timeline'] == 'update'){
	$product = mysql_query("SELECT * FROM product WHERE shop_id='$id'");
	while($each_product = mysql_fetch_assoc($product)){
		$productjson[] = $each_product;
	}
	echo json_encode($productjson);
}
elseif($_POST["timeline"] == 'logout'){
	session_destroy();
}
//[{:"1","vendor_name":"Aren Singh","email":"princesingh0957@gmail.com","mobile":"9633938044","shop_name":"Patna Fashion Store","passs5":"princ","pin_code":"602022","city":"Patna","country":"India","mobile_verify":"1","shop_verified":"1","registered_on":"2016-03-07 00:00:00"}]
?>