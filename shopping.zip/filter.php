<?php

session_start();

$_SESSION['visibilty'] = true;

if(isset($_POST['filter']) && isset($_POST['table'])){
	$sea = $_SESSION['search_product'];
	mysql_connect("localhost","root","");

	mysql_select_db("shopping");
	$table = $_POST['table'];
	
	$latest_product_search = mysql_fetch_assoc(mysql_query("SELECT search FROM $table ORDER BY id DESC LIMIT 1"));
	$sea = $latest_product_search['search'];
	
	if($_POST['filter'] === 'high'){
		$result_to_display = mysql_query("SELECT id,title,small_image,price,old_price,company FROM $table WHERE search='$sea' ORDER BY price DESC LIMIT 20");
		
	}elseif($_POST['filter'] === 'low'){

		$result_to_display = mysql_query("SELECT id,title,small_image,price,old_price,company FROM $table  WHERE search='$sea'  ORDER BY price  LIMIT 20");
	}else{
		$result_to_display = mysql_query("SELECT id,title,small_image,price,old_price,company FROM $table  WHERE search='$sea'  ORDER BY discount DESC  LIMIT 20");
	}
	$each_result_2;
	while($new_result = mysql_fetch_assoc($result_to_display)){
		$each_result_2[] = $new_result;
	}
	echo json_encode($each_result_2);
}
?>