function display(value1,value2){
	document.getElementById(value1).style.display = 'block';
	document.getElementById('change_background').style.display = 'block';
	document.getElementById(value2).style.color = 'green';
}
function hide(value1,value2){
	document.getElementById('change_background').style.display = 'none';
	document.getElementById(value1).style.display = 'none';
}
var i=0;

function show_message(value){
	document.getElementById('display_slide').style.backgroundColor = 'white';
	document.getElementById(value).style.display = 'block';
	i=i+2;
	document.getElementById(value).style.zIndex = i;
}

function get_product(){
	document.getElementById('change_background').style.display = 'none';
	var search_item = document.getElementById('enquered_product').value;
	var max_price = 100;
	if(search_item != ''){
		window.scrollTo(0, 0);
		var xmlhttpsignup;
		if(window.XMLHttpRequest){
			xmlhttpsignup = new XMLHttpRequest();
			
		}else{
			xmlhttpsignup = new ActiveXObject("Microsoft.XMLHTTP");
		}
		params = "search_item=" +search_item;
		
		xmlhttpsignup.open("POST","get_product.php",true);
		
		
		xmlhttpsignup.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xmlhttpsignup.setRequestHeader("Content-length", params.length);
		xmlhttpsignup.setRequestHeader("Connection", "close");
		
		xmlhttpsignup.onreadystatechange=function(){
		  if(xmlhttpsignup.status==200 && xmlhttpsignup.readyState==4){
			  document.getElementById("display_product").style.paddingBottom = '10px';
			   var returned_json = JSON.parse(xmlhttpsignup.responseText);
			   var currency_rs = '&#8377;';
			   document.getElementById('display_product').innerHTML='';
			   
			   for(var iota=0;iota<returned_json.length;iota++){
				   if(returned_json[iota]['old_price'] == 0){
					   returned_json[iota]['old_price'] = '';
				   }
				   var company;
				   if(returned_json[iota]['company'] == 'Flipkart'){
					   company = 'flipkart.jpg';
				   }else{
					   company = 'amazon.jpg';
				   }
				   returned_json[iota]['price'] = parseInt(returned_json[iota]['price']);
				   if(returned_json[iota]['price'] > max_price){
					   max_price = returned_json[iota]['price'];
				   }
				   document.getElementById('display_product').innerHTML +=  "<div onclick=diplay_detail("+returned_json[iota]['id']+",'online') style='width:226px;margin-left:8px; margin-top:9px; height:255px; float:left;position:relative;border:2px solid green;padding:5px;'><div style='width:100%;float:left;position:relative'><div style='width:100%;float:left'><div style='width:100%;float:left;text-align:center;width:220px;height:200px'><img src='"+returned_json[iota]['small_image']+"' style='max-width:200px;max-height:200px' /></div></div><hr><div style='width:100%;float:left'><div style='width:100%;float:left;font-size:14px;color:#333;text-align:center'>"+(returned_json[iota]['title'].substr(0,30)).toLowerCase()+"</div></div><div style='width:100%;float:left;text-align:center;opacity:0.7;background-color:white;color:black;margin-top:-90px;'>Quick View</div><hr><div style='width:100%;float:left'><div style='width:80%;float:left;font-size:16px;font-weight:bold'>Price: &#8377;"+ returned_json[iota]['price'] +"</div><div style='width:19%;float:left; text-decoration:line-through;font-size:12px'> &#8377;"+returned_json[iota]['old_price']+"</div></div><div style='position:absolute;top:2px;right:2px;width:30px;height:30px'><img src='images/"+company+"' style='width:30px;height:30px' /></div></div></div>";
			   }
			   document.getElementById("show_data").style.display = 'block';
			   document.getElementById("page_price_slider").setAttribute('max',max_price);
			   document.getElementById("slider_min_value").innerHTML = "&#8377;"+0+"-->";
			   document.getElementById("slider_max_value").innerHTML = max_price;
			   document.getElementById("page_price_slider").value = max_price;
		   }
		}
		
		xmlhttpsignup.send(params);
		
		document.getElementById('display_product').innerHTML = "<div style='width:100px;height:68px;margin:0 auto;'><img src='images/loading.gif' style='max-width:100px;max-height:68px' /></div>"; 
		document.getElementById("show_data").style.display = 'none';
		
		get_offline(search_item);
		
	}else{
		alert('input some value');
	}
	
}

function get_filer(value){
	var max_price = 100;
	var search_item = value;
	if(search_item != ''){
		window.scrollTo(0, 0);
		var xmlhttpsignup;
		if(window.XMLHttpRequest){
			xmlhttpsignup = new XMLHttpRequest();
			
		}else{
			xmlhttpsignup = new ActiveXObject("Microsoft.XMLHTTP");
		}
		//remove country name india
		params = "search_item=" +search_item;
		
		xmlhttpsignup.open("POST","get_product.php",true);
		
		
		xmlhttpsignup.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xmlhttpsignup.setRequestHeader("Content-length", params.length);
		xmlhttpsignup.setRequestHeader("Connection", "close");
		
		xmlhttpsignup.onreadystatechange=function(){
		  if(xmlhttpsignup.status==200 && xmlhttpsignup.readyState==4){
			  document.getElementById("display_product").style.paddingBottom = '10px';
			   var returned_json = JSON.parse(xmlhttpsignup.responseText);
			   var currency_rs = '&#8377;';
			   document.getElementById('display_product').innerHTML='';
			   
			   for(var iota=0;iota<returned_json.length;iota++){
				   if(returned_json[iota]['old_price'] == 0){
					   returned_json[iota]['old_price'] = '';
				   }
				   var company;
				   if(returned_json[iota]['company'] == 'Flipkart'){
					   company = 'flipkart.jpg';
				   }else{
					   company = 'amazon.jpg';
				   }
				   returned_json[iota]['price'] = parseInt(returned_json[iota]['price']);
				   if(returned_json[iota]['price'] > max_price){
					   max_price = returned_json[iota]['price'];
				   }
				   document.getElementById('display_product').innerHTML += "<div  onclick=diplay_detail("+returned_json[iota]['id']+",'online') style='width:226px;margin-left:8px;margin-top:9px; height:255px; float:left;position:relative;border:2px solid green;padding:5px;'><div style='width:100%;float:left;position:relative'><div style='width:100%;float:left'><div style='width:100%;float:left;text-align:center;width:220px;height:200px'><img src='"+returned_json[iota]['small_image']+"' style='max-width:200px;max-height:200px' /></div></div><hr><div style='width:100%;float:left'><div style='width:100%;float:left;font-size:14px;color:#333;text-align:center'>"+(returned_json[iota]['title'].substr(0,30)).toLowerCase()+"</div></div><div style='width:100%;float:left;text-align:center;opacity:0.7;background-color:white;color:black;margin-top:-90px;'>Quick View</div><hr><div style='width:100%;float:left'><div style='width:80%;float:left;font-size:16px;font-weight:bold'>Price: &#8377;"+ returned_json[iota]['price'] +"</div><div style='width:19%;float:left; text-decoration:line-through;font-size:12px'> &#8377;"+returned_json[iota]['old_price']+"</div></div><div style='position:absolute;top:2px;right:2px;width:30px;height:30px'><img src='images/"+company+"' style='width:30px;height:30px' /></div></div></div>";
			   }
			   document.getElementById("show_data").style.display = 'block';
			   document.getElementById("page_price_slider").setAttribute('max',max_price);
			   document.getElementById("slider_min_value").innerHTML = "&#8377;"+0+"-->";
			   document.getElementById("slider_max_value").innerHTML = max_price;
			   document.getElementById("page_price_slider").value = max_price;
		   }
		}
		
		xmlhttpsignup.send(params);
		
		document.getElementById('display_product').innerHTML = "<div style='width:100px;height:68px;margin:0 auto;'><img src='images/loading.gif' style='max-width:100px;max-height:68px' /></div>"; 
		document.getElementById("show_data").style.display = 'none';
		
		get_offline(value);
	}else{
		alert('input some value');
	}
	
}

function get_comparison(title,company){

	var xmlhttpsignup;
	if(window.XMLHttpRequest){
		xmlhttpsignup = new XMLHttpRequest();
		
	}else{
		xmlhttpsignup = new ActiveXObject("Microsoft.XMLHTTP");
	}
	//remove country name india
	params = "title=" +title+"&company="+company;
	
	xmlhttpsignup.open("POST","compare_product.php",true);
	
	
	xmlhttpsignup.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttpsignup.setRequestHeader("Content-length", params.length);
	xmlhttpsignup.setRequestHeader("Connection", "close");
	
	xmlhttpsignup.onreadystatechange=function(){
	  if(xmlhttpsignup.status==200 && xmlhttpsignup.readyState==4){

	  	document.getElementById('pop_up').style.display = 'block';

		document.getElementById('display_product_item').innerHTML = xmlhttpsignup.responseText;  
	   }
	}
	
	xmlhttpsignup.send(params);
	
	document.getElementById('display_product_item').innerHTML = "<div style='width:100px;height:68px;margin:0 auto;'><img src='images/loading.gif' style='max-width:100px;max-height:68px' /></div>"; 
}
function _pop_up(){

	document.getElementById('pop_up').style.display = 'none';

}
function _popup_block(){

	document.getElementById('change_background').style.display = 'block';
}
function _get_filter_price(filter_option,table){
	
	var xmlhttpfilter;
	if(window.XMLHttpRequest){
		xmlhttpfilter = new XMLHttpRequest();
	}else{
		xmlhttpfilter = new ActiveXObject("Microsoft.XMLHTTP");
	}
	params = "filter=" +filter_option+"&table="+table;
	
	xmlhttpfilter.open("POST","filter.php",true);
	
	xmlhttpfilter.setRequestHeader("Content-length", params.length);
	xmlhttpfilter.setRequestHeader("Connection", "close");
	xmlhttpfilter.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	
	xmlhttpfilter.onreadystatechange=function(){
	  if(xmlhttpfilter.status==200 && xmlhttpfilter.readyState==4){
		   document.getElementById("display_product").style.paddingBottom = '10px';
		   var returned_json = JSON.parse(xmlhttpfilter.responseText);
		   var currency_rs = '&#8377;';
		   document.getElementById('display_product').innerHTML='';
		   
		   for(var iota=0;iota<returned_json.length;iota++){
			   
			   if(returned_json[iota]['old_price'] == 0){
				   returned_json[iota]['old_price'] = '';
			   }
			   var company;
			   if(returned_json[iota]['company'] == 'Amazon'){
				   company = 'amazon.jpg';
			   }else{
				   company = 'flipkart.jpg';
			   }
			   returned_json[iota]['price'] = parseInt(returned_json[iota]['price']);
			   
			   document.getElementById('display_product').innerHTML +=  "<div onclick=diplay_detail("+returned_json[iota]['id']+",'online') style='width:226px;margin-left:8px; margin-top:9px; height:255px; float:left;position:relative;border:2px solid green;padding:5px;'><div style='width:100%;float:left;position:relative'><div style='width:100%;float:left'><div style='width:100%;float:left;text-align:center;width:220px;height:200px'><img src='"+returned_json[iota]['small_image']+"' style='max-width:200px;max-height:200px' /></div></div><hr><div style='width:100%;float:left'><div style='width:100%;float:left;font-size:14px;color:#333;text-align:center'>"+(returned_json[iota]['title'].substr(0,30).toLowerCase())+"</div></div><div style='width:100%;float:left;text-align:center;opacity:0.7;background-color:white;color:black;margin-top:-90px;'>Quick View</div><hr><div style='width:100%;float:left'><div style='width:80%;float:left;font-size:16px;font-weight:bold'>Price: &#8377;"+returned_json[iota]['price']+"</div><div style='width:19%;float:left; text-decoration:line-through;font-size:12px'> &#8377;"+returned_json[iota]['old_price']+"</div></div><div style='position:absolute;top:2px;right:2px;width:30px;height:30px'><img src='images/"+company+"' style='width:30px;height:30px' /></div></div></div>";
			   
		   }
	    }
	}
	xmlhttpfilter.send(params);
	document.getElementById('display_product').innerHTML = "<div style='width:100px;height:68px;margin:0 auto;'><img src='images/loading.gif' style='max-width:100px;max-height:68px' /></div>";
}

function change_product_visibility(val){
	var data = parseInt(document.getElementById("page_price_slider").value);
	
	var xmlfilter;
	if(window.XMLHttpRequest){
		xmlfilter = new XMLHttpRequest();
	}else{
		xmlfilter = new ActiveXObject('Microsoft.XMLHTTP');
	}
	
	parameter = 'value='+data+'&table_name='+val;
	
	xmlfilter.open("POST","get_filter_priced.php",true);
	
	xmlfilter.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlfilter.setRequestHeader("Content-length", parameter.length);
	xmlfilter.setRequestHeader("Connection", "close");
	
	xmlfilter.onreadystatechange = function(){
		if(xmlfilter.status = 200 && xmlfilter.readyState == 4){
			var data_filter = JSON.parse(xmlfilter.responseText);
			document.getElementById("display_product").style.paddingBottom = '10px';
		    document.getElementById("display_product").innerHTML = '';
			document.getElementById("slider_max_value").innerHTML = data;
			
			for(var pi=0;pi<data_filter.length;pi++){
			   if(data_filter[pi]['old_price'] == 0){
				   data_filter[pi]['old_price'] = '';
			   }
			   var company;
			   if(data_filter[pi]['company'] == 'Flipkart'){
				   company = 'flipkart.jpg';
			   }else{
				   company = 'amazon.jpg';
			   }
			   document.getElementById('display_product').innerHTML += "<div  onclick=diplay_detail("+data_filter[pi]['id']+",'online') style='width:226px;margin-left:8px;margin-top:9px; height:255px; float:left;position:relative;border:2px solid green;padding:5px;'><div style='width:100%;float:left;position:relative'><div style='width:100%;float:left'><div style='width:100%;float:left;text-align:center;width:220px;height:200px'><img src='"+data_filter[pi]['small_image']+"' style='max-width:200px;max-height:200px' /></div></div><hr><div style='width:100%;float:left'><div style='width:100%;float:left;font-size:14px;color:#333;text-align:center'>"+(data_filter[pi]['title'].substr(0,30)).toLowerCase()+"</div></div><div style='width:100%;float:left;text-align:center; opacity:0.7; background-color:white;color:black; margin-top:-90px;'>Quick View</div><hr><div style='width:100%;float:left'><div style='width:80%;float:left;font-size:16px;font-weight:bold'>Price: &#8377;"+ data_filter[pi]['price'] +"</div><div style='width:19%;float:left; text-decoration:line-through;font-size:12px'> &#8377;"+data_filter[pi]['old_price']+"</div></div><div style='position:absolute;top:2px;right:2px;width:30px;height:30px'><img src='images/"+company+"' style='width:30px;height:30px' /></div></div></div>";
		   }
		}
	}
	xmlfilter.send(parameter);
}

function diplay_detail(id){
	alert(id);
}
function display_login_screen(){
	document.getElementById("pop_up").style.display = "block";
	document.getElementById("display_product_item").innerHTML = "";
	
	var login;
	if(window.XMLHttpRequest){
		login = new XMLHttpRequest();
	}else{
		login = new ActiveXObject('Microsoft.XMLHTTP');
	}
	login.open("POST","login_signup.php",true);
	
	login.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	login.setRequestHeader("Content-length",0);
	login.setRequestHeader("Connection","close");
	
	login.onreadystatechange = function(){
		if(login.status == 200 && login.readyState == 4){
			document.getElementById("display_product_item").innerHTML = login.responseText;
		}
	}
	login.send();
	
}
function xmlhttplogin(){
	var email = document.getElementById("email").value;
	var password = document.getElementById("password").value;
	
	var save_u_p;
	if(document.getElementById("remember").checked == true){
		save_u_p = 'true';
	}else{
		save_u_p = 'false';
	}
	
	if(email.length >= 6){
		if(password.length >= 6){
			
			var login_jx;
			if(window.XMLHttpRequest){
				login_jx = new XMLHttpRequest();
			}else{
				login_jx = new ActiveXObject('Microsoft.XMLHTTP');
			}
			
			login_parameter = "username="+email+"&password="+password;
			
			login_jx.open("POST","login.php",true);
			
			login_jx.setRequestHeader("Content-type","application/x-www-form-urlencoded");
			login_jx.setRequestHeader("Content-length",login_parameter.length);
			login_jx.setRequestHeader("Connection","close");
			
			login_jx.onreadystatechange = function (){
				if(login_jx.status == 200 && login_jx.readyState == 4){
					if(login_jx.responseText == 'SuccessFul'){
						window.location = "vendors/index.php";
					}else{
						document.getElementById("invalid_credential").style.display = "block";
						document.getElementById("invalid_credential").innerHTML = login_jx.responseText;
					}
				}
			}
			login_jx.send(login_parameter);
			
		}else{
			document.getElementById("invalid_credential").style.display = "block";
			document.getElementById("invalid_credential").innerHTML = "Small Password Length";
		}
	}else{
		document.getElementById("invalid_credential").style.display = "block";
		document.getElementById("invalid_credential").innerHTML = "Small Email ID";
	}
}
 
function diplay_detail(id,status){
	//alert(id+status=onlineor offline);
	document.getElementById("pop_up").style.display = "none";
	var compare_jx;
	if(window.XMLHttpRequest){
		compare_jx = new XMLHttpRequest();
	}else{
		compare_jx = new ActiveXObject('Microsoft.XMLHTTP');
	}
	
	compare_parameter = "pro_id="+id+"&status="+status;
	compare_jx.open("POST","compare_product.php",false);
	
	compare_jx.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	compare_jx.setRequestHeader("Content-length",compare_parameter.length);
	compare_jx.setRequestHeader("Connection","close");
	
	compare_jx.onreadystatechange = function(){
		if(compare_jx.status == 200 && compare_jx.readyState == 4){
			document.getElementById("pop_up").style.display = "block";
			document.getElementById("display_product_item").innerHTML = compare_jx.responseText;
		}
	}
	compare_jx.send(compare_parameter);
}

function get_offline(offline_data){
	var offline_jx;
	if(window.XMLHttpRequest){
		offline_jx = new XMLHttpRequest();
	}else{
		offline_jx = new ActiveXObject('Microsoft.XMLHTTP');
	}
	
	param = "offline="+offline_data;
	alert(param);
	offline_jx.open("POST","offline.php",false);
	
	offline_jx.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	offline_jx.setRequestHeader("Content-length",param.length);
	offline_jx.setRequestHeader("Connection","close");
	
	offline_jx.onreadystatechange = function(){
		if(offline_jx.status == 200 && offline_jx.readyState ==4){
			document.getElementById("main_offline_section").style.display = "block";
			document.getElementById("main_offline_section").style.paddingBottom = "10px";
			document.getElementById("display_offline_products").innerHTML = "";
			var offline_product = JSON.parse(offline_jx.responseText);
			
			for(var pro =0 ;pro < offline_product.length; pro++){
				
				document.getElementById('display_offline_products').innerHTML += "<div  onclick=diplay_detail("+offline_product[pro]['id']+",'offline') style='width:226px;margin-left:8px;margin-top:9px; height:255px; float:left;position:relative;border:2px solid green;padding:5px;'><div style='width:100%;float:left;position:relative'><div style='width:100%;float:left'><div style='width:100%;float:left;text-align:center;width:220px;height:200px'><img src='"+offline_product[pro]['small_image']+"' style='max-width:200px;max-height:200px' /></div></div><hr><div style='width:100%;float:left'><div style='width:100%;float:left;font-size:14px;color:#333;text-align:center'>"+(offline_product[pro]['title'].substr(0,30)).toLowerCase()+"</div></div><div style='width:100%;float:left;text-align:center; opacity:0.7; background-color:white;color:black; margin-top:-90px;'>Quick View</div><hr><div style='width:100%;float:left'><div style='width:80%;float:left;font-size:16px;font-weight:bold'>Price: &#8377;"+ offline_product[pro]['price'] +"</div><div style='width:19%;float:left; text-decoration:line-through;font-size:12px'> &#8377;"+offline_product[pro]['old_price']+"</div></div></div></div>";
			}
		}
	}
	offline_jx.send(param);

}

function add_to_cart(table,pro_id,pro_status,sell_status,small_image,price,shop_id,shop_name,pro_name){
	var cart;
	if(window.XMLHttpRequest){
		cart = new XMLHttpRequest();
	}else{
		cart = new ActiveXObject("Microsoft.XMLHTTP")
	}
	parameter = "table="+table+"&pro_id="+pro_id+"&pro_obtained="+pro_status+"&sell_status="+sell_status+"&image="+small_image+"&price="+price+"&shop_id="+shop_id+"&shop_name="+shop_name+"&pro_name="+pro_name;
	
	
	cart.open("POST","add_to_cart.php",false);
	
	cart.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	cart.setRequestHeader("Content-length",parameter.length);
	cart.setRequestHeader("Connection","close");
	
	cart.onreadystatechange = function(){
		if(cart.status == 200 && cart.readyState == 4){
			document.getElementById('cart_added').innerHTML = (cart.responseText);
		}
	}
	cart.send(parameter);
}

function get_cart_product(value){
	if(document.getElementById('show_cart_product').style.display == 'none'){
		
		var pro;
		if(window.XMLHttpRequest){
			pro = new XMLHttpRequest();
		}else{
			pro = new ActiveXObject('Microsoft.XMLHTTP');
		}
		param = 'tbl='+value;
		
		pro.open('POST','get_cart_pro.php',false);
		
		pro.setRequestHeader('Content-type','application/x-www-form-urlencoded');
		pro.setRequestHeader('Content-length',param.length);
		pro.setRequestHeader('Connection','close');
		
		pro.onreadystatechange = function(){
			if(pro.status == 200 && pro.readyState == 4){
				document.getElementById('show_cart_product').style.display  = 'block';
				document.getElementById('show_cart_product').innerHTML = (pro.responseText);
			}
		}
		pro.send(param);
	}else{
		document.getElementById('show_cart_product').style.display  = 'none';
	}
	
}
function remove_cart(value){
	var pro;
	if(window.XMLHttpRequest){
		pro = new XMLHttpRequest();
	}else{
		pro = new ActiveXObject('Microsoft.XMLHTTP');
	}
	param = 'tbl='+value;
	
	pro.open('POST','remove_cart.php',false);
	
	pro.setRequestHeader('Content-type','application/x-www-form-urlencoded');
	pro.setRequestHeader('Content-length',param.length);
	pro.setRequestHeader('Connection','close');
	
	pro.onreadystatechange = function(){
		if(pro.status == 200 && pro.readyState == 4){
			document.getElementById('show_cart_product').style.display  = 'block';
			document.getElementById('show_cart_product').innerHTML = (pro.responseText);
		}
	}
	pro.send(param);
}

function find_city(){
	var city_name = document.getElementById('find_city').value
	
	var city;
	if(window.XMLHttpRequest){
		city = new XMLHttpRequest();
	}else{
		city = new ActiveXObject('Microsoft.XMLHTTP');
	}
	param = 'city_name='+city_name;
	
	city.open('POST','get_shop.php',false);
	
	city.setRequestHeader('Content-type','application/x-www-form-urlencoded');
	city.setRequestHeader('Content-length',param.length);
	city.setRequestHeader('Connection','close');
	
	city.onreadystatechange = function(){
		if(city.status == 200 && city.readyState == 4){
			document.getElementById('show_cart_product').style.display  = 'block';
			document.getElementById('display_offline_products').innerHTML = (city.responseText);
		}
	}
	city.send(param);
}