<?php
	if(isset($_POST["username"])&& isset($_POST["password"])){
		
		$email = filter_input(INPUT_POST,"username",FILTER_SANITIZE_EMAIL);
		$password = filter_input(INPUT_POST,"password",FILTER_SANITIZE_MAGIC_QUOTES);
		
		mysql_connect("localhost","root","");
		mysql_select_db("vendors_shop");
		
		$password_enc = substr($password,0,5);
		
		$password = md5($password);
		
		$email_enc = substr($email,0,5);
		
		$result = mysql_query("SELECT shop_id,penc,eenc,pw from user_verification WHERE email='$email'");
		
		if(mysql_num_rows($result) == 1){
			$small_result = mysql_fetch_assoc($result);
			
			if($small_result["pw"] == $password && $small_result["penc"] == $password_enc && $small_result["eenc"] == $email_enc){
				
				session_start();
				$_SESSION['id'] = $small_result['shop_id'];
				echo "SuccessFul";

			}else{
				echo "Login Unsuccessful";
			}
			
		}else{
			echo "Login Unsuccessful";
		}
		
	}else{
		echo "Wrong Intention";
	}
?>