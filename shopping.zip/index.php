<?php
mysql_connect("localhost","root","");

mysql_select_db("shopping");

error_reporting(0);

function get_client_ip_env() {
	$ipaddress = '';
	if (getenv('HTTP_CLIENT_IP'))
		$ipaddress = getenv('HTTP_CLIENT_IP');
	else if(getenv('HTTP_X_FORWARDED_FOR'))
		$ipaddress = getenv('HTTP_X_FORWARDED_FOR');
	else if(getenv('HTTP_X_FORWARDED'))
		$ipaddress = getenv('HTTP_X_FORWARDED');
	else if(getenv('HTTP_FORWARDED_FOR'))
		$ipaddress = getenv('HTTP_FORWARDED_FOR');
	else if(getenv('HTTP_FORWARDED'))
		$ipaddress = getenv('HTTP_FORWARDED');
	else if(getenv('REMOTE_ADDR'))
		$ipaddress = getenv('REMOTE_ADDR');
	else
		$ipaddress = 'UNKNOWN';

	return $ipaddress;
}

$ip = get_client_ip_env();

$ip = "ipaddr".str_replace(':','00',trim($ip));

session_start();

$_SESSION['tbl_name'] = $ip;

mysql_query("
	CREATE TABLE $ip (
		id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
		title VARCHAR(400) NOT NULL,
		category VARCHAR(400),
		brand VARCHAR(200),
		small_image VARCHAR(400),
		large_image varchar(400),
		prod_desc TEXT,
		prod_link VARCHAR(1000),
		price INT,
		old_price INT,
		company TEXT,
        discount float,
		search VARCHAR(400)
	);
");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Simple Shopping</title>
<script src="js/jquery.js" type="text/javascript"></script>
<script src="js/index.js" type="text/javascript"></script>
<script src="vendors/js/index.js" type="text/javascript"></script>
<!--<script src="facebook.js" type="text/javascript"></script> -->
<style>
body{
	margin:0 auto;
	padding:0px;
	background-image: url(4.png);
}
#pop_up:before{
	opacity:0.7;
}
#pop_up{
	background-color: rgba(0,0,0,0.5);
}
#men_list div div{
    cursor: pointer;
}
#women_list div div{
    cursor: pointer;
}
#book_list div div{
    cursor:pointer;
}
#sport_list div div{
    cursor:pointer;
}
#men_list_bottom div div div{
    cursor:pointer;
}
#women_list_bottom div div div{
    cursor:pointer;
}
#sport_list_bottom div div div{
    cursor:pointer;
}
#book_list_bottom div div div{
    cursor:pointer;
}
.login_main{width:400px;margin:0 auto}
.login_wrap{width:100%;float:left;border:1px solid green}
.all_same{width:99%;float:left}
.login_main_content{width:95%;margin:0 auto}
.login_main_content div{width:100%;float:left}
.login_main_content div label{width:100%;float:left}
.special_login_header{padding:5px;text-align:center;margin-top:-25px;width:97%;}
.special_login_header h2{background-color:#CCC;}

</style>

</head>
<body>

<div style='width:100%;float:left'>
	<div style='width:100%;float:left'>
    	<div style='width:100%;float:left'>
        	<header style='width:100%;height:90px;background-color:#027cd5;float:left;position:fixed;z-index:10000;display:block'>
            	<div style='width:100%;float:left;;'>
                	<div style='width:750px;margin:0 auto'>
                    	<div style='width:100%;float:left'>
                        	<div style='padding-top:10px'>
                            	<div style='width:100%;float:left'>
                                	<div style='float:left'>
                                    	<div style='float:left;margin:4px;font-size:30px;color:white'>
                                        	Simple Shop<br />
                                        </div>
                                    </div>
                                    <div style='float:left;margin-left:4px;background-color:white;margin-top:5px;'>
                                    	<div style='width:445px;float:left;border:2px solid white'>
                                        	<div style='width:400px;float:left'>
                                            	<input onfocus=_popup_block() type='text' placeholder='Find Product' id='enquered_product' style='width:100%;height:auto;padding:5px;border:none;outline:none' />
                                            </div>
                                            <div style='width:30px;float:left;margin-left:14px;cursor:pointer' onclick=get_product()>
                                            	<img src='images/search.png' width='30px' height='28px' style='border:none;' />
                                            </div>
                                        </div>
                                    </div>
                                    <div style='float:left;margin-left:4px;background-color:white;margin-top:5px;' title="Cart" onclick=get_cart_product('<?php echo $_SESSION['tbl_name'] ?>')>
                                    <div id="show_cart_product" style="background-color:white;margin-top:30px;border:1px solid green;width:430px;height:auto;position:absolute;margin-left:-200px;display:none"></div>
                                    	<div style="">
                                        	<div style="float:left;">
                                            	<img src="images/shop.jpg" style="width:27px;height:27px;padding:2px" />
                                            </div>
                                            <div style="float:left;margin-left:3px;padding:6px;font-weight:bold" id="cart_added">
                                            	<?php
													$table = $_SESSION["tbl_name"];
													echo  mysql_num_rows(mysql_query("SELECT * FROM cart WHERE table_name = '$table'"));
												?>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                       			<div style='width:100%;float:left;margin-top:10px;z-index:1000'>
                                	<div style='margin:0 auto;width:670px'>
                                    	<div style='cursor:pointer;padding:4px;float:left;width:100px' onmouseover=display('men_list') onmouseout=hide('men_list','men')>
                                        	<div id="men">
                                            	<div style='float:left'><img src='images/men.png' height='20px' width='20px' /></div>
                                                <div style='float:left;color:white;padding-left:4px'>Men</div>
                                            </div>
                                            <div id='men_list' style='position:absolute;margin-top:24px;display:none;z-index:1000'>
                                            	<div style='width:0px;height:0px;border-bottom:4px solid #00172F;border-left:4px solid transparent;     border-right:4px solid transparent;;'></div>
                                            	<div style='border:2px solid #00172F;padding:4px;background-color:white;'>
                                                    <div onclick=get_filer('Shirt')>Shirt</div><hr />
                                                    <div onclick=get_filer('T-shirt')>T-shirt</div><hr />
                                                    <div onclick=get_filer('Sneakers')>Sneakers</div><hr />
                                                    <div onclick=get_filer('Shoes')>Shoes</div><hr />
                                                    <div onclick=get_filer('Watch+Wallet')>Watch Or Wallet</div><hr />
                                                    <div onclick=get_filer('Trouser')>Trouser</div><hr />
                                                    <div onclick=get_filer('Jeans')>Jeans</div><hr />
                                                    <div onclick=get_filer('Combo+Offer')>Combo Offer</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div style='cursor:pointer;padding:4px;float:left;width:100px;margin-left:10px;'  onmouseover=display('women_list') onmouseout=hide('women_list','women')>
                                        	<div id="women">
                                            	<div style='float:left'><img src='images/women.jpg' height='20px' width='20px' /></div>
                                                <div style='float:left;color:white;padding-left:4px'>Women</div>
                                            </div>
                                           <div id='women_list' style='position:absolute;margin-top:24px;display:none;z-index:1000'>
                                            	<div style='width:0px;height:0px;border-bottom:4px solid #00172F;border-left:4px solid transparent;     border-right:4px solid transparent;;'></div>
                                            	<div style='border:2px solid #00172F;padding:4px;background-color:white;'>
                                                    <div onclick=get_filer('Kurtas And Kurtis')>Kurtas And Kurtis</div><hr />
                                                    <div onclick=get_filer('Saree')>Saree</div><hr />
                                                    <div onclick=get_filer('Salwar Kurta And Dupatta')>Salwar Kurta And Dupatta</div><hr />
                                                    <div onclick=get_filer('Heal')>Heal</div><hr />
                                                    <div onclick=get_filer('Wedges')>Wedges</div><hr />
                                                    <div onclick=get_filer('Hand+Bag')>Hand Bag</div><hr />
                                                    <div onclick=get_filer('Sling+Bag')>Sling Bag</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div style='cursor:pointer;padding:4px;);float:left;width:100px;margin-left:10px'  onmouseover=display('book_list') onmouseout=hide('book_list','book')>
                                        	<div id="book">
                                            	<div style='float:left'><img src='images/book.png' height='20px' width='20px' /></div>
                                                <div style='float:left;color:white;padding-left:4px'>Books</div>
                                            </div>
                                            <div id='book_list' style='position:absolute;margin-top:24px;display:none;z-index:1000'>
                                            	<div style='width:0px;height:0px;border-bottom:4px solid #00172F;border-left:4px solid transparent;     border-right:4px solid transparent;;'></div>
                                            	<div style='border:2px solid #00172F;padding:4px;background-color:white;'>
                                                    <div onclick=get_filer('Pre+Order')>Pre-Order</div><hr />
                                                    <div onclick=get_filer('New+Release')>New Release</div><hr />
                                                    <div onclick=get_filer('Best+Seller')>Best Seller</div><hr />
                                                    <div onclick=get_filer('Literature+And+Fiction')>Literature And Fiction</div><hr />
                                                    <div onclick=get_filer('Comics+And+Graphics+Nobel')>Comics And Graphics Nobel</div><hr />
                                                    <div onclick=get_filer('Pens+And+Notebook')>Pens And Notebook</div><hr />
                                                    <div onclick=get_filer('Academic+Book')>Academic Book</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div style='cursor:pointer;padding:4px;;float:left;width:100px;margin-left:10px' onmouseover=display('sport_list') onmouseout=hide('sport_list','sport')>
                                        	<div>
                                            	<div style='float:left'><img src='images/sport.png' height='20px' width='20px' /></div>
                                                <div id="sport" style='float:left;color:white;padding-left:4px'>Sports</div>
                                            </div>
                                            <div id='sport_list' style='position:absolute;margin-top:24px;display:none;z-index:1000'>
                                            	<div style='width:0px;height:0px;border-bottom:4px solid #00172F;border-left:4px solid transparent;     border-right:4px solid transparent;;'></div>
                                            	<div style='border:2px solid #00172F;padding:4px;background-color:white;'>
                                                    <div onclick=get_filer('Cricket')>Cricket</div><hr />
                                                    <div onclick=get_filer('Badminton')>Badminton</div><hr />
                                                    <div onclick=get_filer('Football')>Football</div><hr />
                                                    <div onclick=get_filer('Swimming')>Swimming</div><hr />
                                                    <div onclick=get_filer('Table+Tennis')>Table Tennis</div><hr />
                                                    <div onclick=get_filer('Tennis')>Tennis</div><hr />
                                                    <div onclick=get_filer('Boxing')>Boxing</div><hr />
                                                    <div onclick=get_filer('BasketBall')>BasketBall</div><hr />
                                                    <div onclick=get_filer('Show+All+sports')>Show All Product</div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
										if(isset($_SESSION['id'])){
											echo "<div style='cursor:pointer;padding:4px;background-color:rgba(0,74,210,0.68);float:left;width:124px;margin-left:10px;position:absolute;top:20px;right:20px' onclick=fetch_detail('logout','".$_SESSION['id']."') >
													<div>
														<div style='float:left'><img src='images/login.jpg' height='20px' width='20px' /></div>
														<div style='float:left;color:white'>LogOut</div>
													</div>                                        	
												</div>
											";
										}else{
											echo "<div style='cursor:pointer;padding:4px;;float:left;width:124px;margin-left:10px;' onclick=display_login_screen() >
													<div>
														<div style='float:left'><img src='images/login.jpg' height='20px' width='20px' /></div>
														<div style='float:left;color:white'>Login/SignUp</div>
													</div>                                        	
												</div>
											";
										}
                                        
										?>
                                        	
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <article style='width:100%;float:left;margin-top:100px;position:relative;z-index:0'>
            	<div style='width:100%;float:left'>
                	<div style='width:750px;margin:0 auto'>
                    	<div style='width:100%;float:left;border:2px solid #02A04C;margin-top:20px;background-color:white;' id='display_product'>
                        	<div style='width:100%;float:left'>
                            	<div  style='width:100%;float:left;height:300px;position:relative' id='display_slide'>
                                	<?php
									mysql_connect("localhost","root","");									
									mysql_select_db("shopping");
									$result = mysql_query("SELECT * FROM trending ORDER BY id DESC LIMIT 4");
									
									while($data = mysql_fetch_assoc($result)){
									$i=5;
									echo "<div id='".$data['Name']."' style='width:100%;float:left;height:310px;position:absolute; z-index:".$i.";background-color:white'>
											<a href='".$data['link']."' target='_blank'>
												<div style='padding:4px'>
													<div style='width:auto;height:300px;float:left;position:relative'>
														<img src='".$data['image']."' style='height:310px;width:100%;max-width:100%;position:relative' />
													</div>
												</div>
											  </a>
										  </div>";
										$i++;
									}
								?>
                                </div>
                             </div>
                             <div style='width:410px;float:left;text-align:center;padding:4px;margin:4px;margin-top:20px;'>
                                <div style='width:100px;float:left;border-right:2px solid green;cursor:pointer' onmouseover=show_message('Men')>Men</div>
                                <div style='width:100px;float:left;border-right:2px solid green;cursor:pointer' onmouseover=show_message('Women')>Women</div>
                                <div style='width:100px;float:left;border-right:2px solid green;cursor:pointer' onmouseover=show_message('Sports')>Sports</div>
                                <div style='width:100px;float:left;;cursor:pointer' onmouseover=show_message('Books')>Books</div>
                            </div>
                        </div>
                        <div style="width:100%;float:left;border:2px solid green;margin-top:20px;background-color:white;" id="main_offline_section">
                        	<div style="padding:7px">
                            	<div>Offline Section</div>
                                <hr />
                            	<div style="width:100%;float:left">
                                	<div style="width:100%;float:left;padding-bottom:10px" id="display_offline_products">
                                    	<input id="find_city" type="text" style="width:83%;float:left;padding:10px;height:auto;"  placeholder="Enter Your City Name(Prototype:patna)"/>
                                        <button style='width:100px;float:left;padding:11px;outline:none;border:1px solid green' onclick=find_city()>Search</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div style="width:100%;float:left;border:2px solid green;margin-top:20px;background-color:white;display:none" id="twitter">
                        	<div style="padding:7px">
                            	<div>People Taking About</div>
                                <hr />
                            	<div style="width:100%;float:left" id="twitter_holder">
                                    	
                                </div>
                            </div>
                        </div>
                        <div style='width:100%;float:left; margin-top:20px;'>
                        	<div style='width:100%;float:left;'>
                            	<div style='width:100%;float:left;'>
                                	<div style='width:100%;float:left;'>
                                    	<div style='width:100%;float:left;'>
                                        <div style='width:100%;float:left;font-size:18px;color:#44;padding:4px'>Men Trending</div>
                                        
                                        <?php
                                        	$result_small = mysql_query("SELECT * FROM day_trending WHERE category = 'Men'  LIMIT 2");

											echo "<div style='width:100%;float:left;height:250px;min-width:750px;'>
													<div style='padding:4px;'>
														<div style='width:100%;float:left;'>
															<div style='float:left;width:200px;height:240px;background-color:#eeeeee;border-right:1px solid green' id='men_list_bottom'>
																<div style='padding:10px'>
																		<div style='width:100%;float:left'>
																			<div onclick=get_filer('Shirts')>
																				Shirts
																			</div onclick=get_filer('Show All Product')>
																			<hr>
																			<div onclick=get_filer('Tshirts')>
																				Tshirts
																			</div>
																			<hr>
																			<div onclick=get_filer('Jeans')>
																				Jeans
																			</div>
																			<hr>
																			<div onclick=get_filer('Trouser')>
																				Trouser
																			</div>
																			<hr>
																			<div onclick=get_filer('Sweater')>
																				Sweater
																			</div>
																			<hr>
																			<div onclick=get_filer('SweatShirt')>
																				SweatShirt
																			</div>
																			<hr>
																		</div>
																	</div>
															</div>
																<div style='float:left;width:530px;height:240px;'>
																	<div style='float:left'>
																		<div style='width:550px;height:250px;float:left'>";
																		while($each_result = mysql_fetch_assoc($result_small)){
																			echo "<div style='width:266px;height:240px;float:left;position:relative;cursor:pointer' onclick=get_filer('".str_replace(' ','+', $each_result['name'])."')>
																					<div style='float:left'>
																						<img src='".$each_result['location']."' style='width:268px;height:240px;float:left' />
																					 </div>
																					 <div style='position:absolute;bottom:0px;right:0px;'>".$each_result['name']."</div>
																				  </div>";
																				  echo "<div style='width:3px; height:240px;background-color:green; float:left'></div>";
																			}
																	echo "</div>
																	</div>
																</div>
															</div>
														</div>
													 </div>";
													?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div style='width:100%;float:left;margin-top:20px'>
                        	<div style='width:100%;float:left;'>
                            	<div style='width:100%;float:left;'>
                                	<div style='width:100%;float:left;'>
                                    	<div style='width:100%;float:left;'>
                                        	<div style='width:100%;float:left;font-size:18px;color:#44;padding:4px'>Women Trending</div>
                                       		
                                         	<?php
                                        	$result_small = mysql_query("SELECT * FROM day_trending WHERE category = 'Women'  LIMIT 2");

											echo "<div style='width:100%;float:left;height:250px;min-width:750px;'>
													<div style='padding:4px;'>
														<div style='width:100%;float:left;'>
															<div style='float:left;width:200px;height:240px;background-color:#eeeeee;border-right:1px solid green'  id='women_list_bottom'>
																<div style='padding:10px'>
																		<div style='width:100%;float:left'>
																			<div onclick=get_filer('Saree')>
																				Saree
																			</div>
																			<hr>
																			<div onclick=get_filer('Salwar+Suits')>
																				Salwar Suits
																			</div>
																			<hr>
																			<div onclick=get_filer('Kurtis')>
																				Kurtis
																			</div>
																			<hr>
																			<div onclick=get_filer('Lehengas')>
																				Lehengas
																			</div>
																			<hr>
																			<div onclick=get_filer('Saree+Combos')>
																				Saree Combos
																			</div>
																			<hr>
																			<div onclick=get_filer('Salwars+Churidars')>
																				Salwars & Churidars
																			</div>
																			<hr>
																		</div>
																	</div>
															</div>
																<div style='float:left;width:530px;height:240px;'>
																	<div style='float:left'>
																		<div style='width:550px;height:250px;float:left'>";
																		while($each_result = mysql_fetch_assoc($result_small)){
																			echo "<div style='width:266px;height:240px;float:left;position:relative;' onclick=get_filer('".str_replace(' ','+', $each_result['name'])."')>
																					<div style='float:left'>
																						<img src='".$each_result['location']."' style='width:268px;height:240px;float:left' />
																					 </div>
																					 <div style='position:absolute;bottom:0px;right:0px;'>".$each_result['name']."</div>
																				  </div>";
																				  echo "<div style='width:3px; height:240px;background-color:green; float:left'></div>";
																			}
																	echo "</div>
																	</div>
																</div>
															</div>
														</div>
													 </div>";
													?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div style='width:100%;float:left;margin-top:20px;'>
                        	<div style='width:100%;float:left;'>
                            	<div style='width:100%;float:left;'>
                                	<div style='width:100%;float:left;'>
                                    	<div style='width:100%;float:left;'>
                                            <div style='width:100%;float:left;font-size:18px;color:#44;padding:4px'>Sports And Fitness</div>
                                            
                                        	<?php
                                        	$result_small = mysql_query("SELECT * FROM day_trending WHERE category = 'Sport'   LIMIT 2");

											echo "<div style='width:100%;float:left;height:250px;min-width:750px;'>
													<div style='padding:4px;'>
														<div style='width:100%;float:left;'>
															<div style='float:left;width:200px;height:240px;background-color:#eeeeee;border-right:1px solid green'  id='game_list_bottom'>
																<div style='padding:10px'>
																		<div style='width:100%;float:left'>
																			<div onclick=get_filer('Fitness')>
																				Gyms & Fitness Equipment
																			</div>
																			<hr>
																			<div onclick=get_filer('Mats')>
																				Yoga Mats
																			</div>
																			<hr>
																			<div onclick=get_filer('Gym+gloves+belt')>
																				Gym Gloves and Belts
																			</div>
																			<hr>
																			<div onclick=get_filer('Badminton')>
																				Badminton
																			</div>
																			<hr>
																			<div onclick=get_filer('Football')>
																				Football
																			</div>
																			<hr>
																			<div onclick=get_filer('Cricket')>
																				Cricket
																			</div>
																			<hr>
																		</div>
																	</div>
															</div>
																<div style='float:left;width:530px;height:240px;'>
																	<div style='float:left'>
																		<div style='width:550px;height:250px;float:left'>";
																		while($each_result = mysql_fetch_assoc($result_small)){
																			echo "<div style='width:266px;height:240px;float:left;position:relative;' onclick=get_filer('".str_replace(' ','+', $each_result['name'])."')>
																					<div style='float:left'>
																						<img src='".$each_result['location']."' style='width:268px;height:240px;float:left' />
																					 </div>
																					 <div style='position:absolute;bottom:0px;right:0px;'>".$each_result['name']."</div>
																				  </div>";
																				  echo "<div style='width:3px; height:240px;background-color:green; float:left'></div>";
																			}
																	echo "</div>
																	</div>
																</div>
															</div>
														</div>
													 </div>";
													?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div style='width:100%;float:left;margin-top:20px'>
                        	<div style='width:100%;float:left;'>
                            	<div style='width:100%;float:left;'>
                                	<div style='width:100%;float:left;'>
                                    	<div style='width:100%;float:left;'>
                                            <div style='width:100%;float:left;font-size:18px;color:#44;padding:4px'>Books</div>
                                            <?php
                                                $result_small = mysql_query("SELECT * FROM day_trending WHERE category = 'Book'   LIMIT 2");
    
                                                echo "<div style='width:100%;float:left;height:250px;min-width:750px;'>
                                                        <div style='padding:4px;'>
                                                            <div style='width:100%;float:left;'>
                                                                <div style='float:left;width:200px;height:240px;background-color:#eeeeee;border-right:1px solid green' id='book_list_bottom'>
                                                                    <div style='padding:10px'>
                                                                            <div style='width:100%;float:left'>
                                                                                <div onclick=get_filer('Literature+and+Fiction')>
                                                                                    Literature & Fiction
                                                                                </div>
                                                                                <hr>
                                                                                <div onclick=get_filer('Competitive+Exams+Guides')>
                                                                                    Competitive Exams Guides
                                                                                </div>
                                                                                <hr>
                                                                                <div onclick=get_filer('Academic+and+Professional+books')>
                                                                                    Academic & Professional
                                                                                </div>
                                                                                <hr>
                                                                                <div onclick=get_filer('Children+and+Young+Adults+books')>
                                                                                    Children & Young Adults
                                                                                </div>
                                                                                <hr>
                                                                                <div onclick=get_filer('School+books')>
                                                                                    School Books
                                                                                </div>
                                                                                <hr>
                                                                                <div onclick=get_filer('Business+study')>
                                                                                    Business
                                                                                </div>
                                                                                <hr>
                                                                            </div>
                                                                        </div>
                                                                </div>
                                                                    <div style='float:left;width:530px;height:240px;'>
                                                                        <div style='float:left'>
                                                                            <div style='width:550px;height:250px;float:left'>";
                                                                            while($each_result = mysql_fetch_array($result_small)){
                                                                                echo "<div style='width:266px;height:240px;float:left;position:relative;' onclick=get_filer('".str_replace(' ','+', $each_result['name'])."')>
                                                                                        <div style='float:left'>
                                                                                            <img src='".$each_result['location']."' style='width:268px;height:240px;float:left' />
                                                                                         </div>
                                                                                         <div style='position:absolute;bottom:0px;right:0px;'>".$each_result['name']."</div>
                                                                                      </div>";
                                                                                      echo "<div style='width:3px; height:240px;background-color:green; float:left'></div>";
                                                                                }
                                                                        echo "</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                         </div>";
                                                        ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </article>
            <footer></footer>
        </div>
    </div>
</div>

<div style='display:none; position:fixed; top:0px; left:0px; right:0px; bottom:0px; width:100%; height:100%; opacity:0.4 float:left; z-index:10000; ' id='pop_up'>
	<div style='width:100%;float:left;position:relative'>
		<div style='width:756px;margin:0 auto;position:relative'>
        	<div style='position:absolute;background-color:red;width:60px;height:20px;top:93px;right:-8px;z-index:100000;cursor:pointer;padding:4px;text-align:center'onclick = _pop_up()>Close</div>
			<div style='width:100%;float:left;height:auto;border:1px solid green;margin-top:100px; opacity:1; z-index:20000; background-color:white; padding-bottom:10px;position:relative' id='display_product_item'></div>
		</div>
	</div>
</div>

<div style='position:fixed; top:100px; right:0px; width:200px; height:auto; opacity:1.0; z-index:100;border:1px solid green;padding-bottom:10px;background-color:white; display:none' id='show_data' >
    <div style='width:100%;float:left'>
        <div style='width:100%;height:auto;float:left;'>
            <div style='color:green;font-size:16px;padding:4px'>Filter Products</div>
            <hr>
            <div style='width:100%;height:auto;float:left;color:grey'>
                <div style='width:100%;float:left;padding-left:10px;cursor:pointer' onclick = _get_filter_price('high','<?php echo $_SESSION['tbl_name'] ?>')>Price : High To Low</div>
                <hr>
                <div style='width:100%;float:left;padding-left:10px;cursor:pointer' onclick = _get_filter_price('low','<?php echo $_SESSION['tbl_name'] ?>')>Price : Low To High</div>
                <hr>
                <div style='width:100%;float:left;padding-left:10px;cursor:pointer'>
                    <div style='width:100%;float:left'>
                    Price-Range(min to max)
                    <input type='range' min='0' max='100' style='width:75%;float:left' id='page_price_slider' onchange=change_product_visibility('<?php echo $_SESSION['tbl_name'] ?>')>
                    </div>
                    <div style='width:100%;float:left'>
                    	<div style='width:40%;float:left' id='slider_min_value'></div>-
                        <div style='width:57%;float:left' id='slider_max_value'></div>
                    </div>
                </div>
                <hr>
                <div style='width:100%;float:left;padding-left:10px;cursor:pointer' onclick = _get_filter_price('discount','<?php echo $_SESSION['tbl_name'] ?>')>
                    Discount(High To Low)
                </div>
            </div>
        </div>
    </div>
</div>
<div style='position:fixed; bottom:10px; right:0px; width:auto; opacity:1.0; z-index:100;border:1px solid green;padding-bottom:10px;padding:10px; cursor:pointer; background-color:white'>
    <div style='width:100%;float:left'>
        <div style='width:100%;float:left;height:auto; opacity:1; z-index:20000; ' >
            <fb:login-button scope="public_profile,email" onlogin="checkLoginState();">
            </fb:login-button>

            <div id="status">
            </div>
        </div>
    </div>
</div>
<div style="width:100%;height:100%;margin-top:90px;position:fixed;z-index:1000;background-color:rgba(51,51,51,0.34);display:none" id="change_background"></div>
</body>

</html>
</html>