<?php
	echo '
	<article style="width:100%;float:left;">
		<div style="width:100%;float:left">
			<div style="width:95%;margin:0 auto;">
				<div style="width:220px;padding:10px;height:20px;margin:0 auto;margin-top:10px;border:1px solid #027cd5;padding-left:15px;padding-right:15px;background-color:#027cd5;color:white;font-size:18px">Login</div>
				<div style="width:220px;margin:0 auto;border:1px solid #027cd5;padding:15px;background-color:#ECF5FF">
					<div style="color:red;display:none" id="invalid_credential">Invalid Credential</div>
					<label style="width:210px;height:auto;float:left;">
						<input type="text" placeholder="UserName" style="width:100%;padding:3px;border:1px solid lightgrey" id="email" autocomplete="on"/>
					</label>
					<label style="width:210px;height:auto;float:left;margin-top:5px">
						<input type="checkbox" value=1 id="remember"/><span style="margin-left:5px">Remember Me</span>
					</label>
					<label style="width:210px;height:auto;float:left;margin-top:15px;">
						<input type="password" placeholder="Password"  style="width:100%;padding:3px;border:1px solid lightgrey" id="password" />
					</label>
					<label style="width:210px;height:auto;float:left;margin-top:5px;">
						<a href="#">Problem With Login</a>
					</label>
					<label  style="width:210px;height:auto;">
						<button style="width:100%;margin-top:20px;background-color:#027cd5;border:none;outline:none;padding:5px;color:white; cursor:pointer" onclick=xmlhttplogin()>Login...</button>
					</label>
				   
				</div>
				<div style="width:220px;padding:10px;height:20px;margin:0 auto;margin-top:10px;border:1px solid #027cd5;padding-left:15px;padding-right:15px;background-color:#027cd5;color:white;font-size:18px;cursor:pointer;">Sign Up</div>
			</div>
		</div>
	</article>';
?>