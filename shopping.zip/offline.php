<?php
	if(isset($_POST['offline'])){
		$search = filter_input(INPUT_POST,"offline",FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
		
		mysql_connect("localhost","root","");
		
		mysql_select_db("vendors_shop");
		
		$result = mysql_query("SELECT DISTINCT * FROM product WHERE title LIKE '$search' OR title LIKE '%$search' OR title LIKE '$search%' OR title LIKE '%$search%' ");
		if(mysql_num_rows($result) > 0){
			while($each_result = mysql_fetch_assoc($result)){
				$offline_pro[] = $each_result;
			}
			echo json_encode($offline_pro);
		}else{
			echo "No Result Found";
		}
		
		
	}else{
		echo "something wrong";
	}
?>